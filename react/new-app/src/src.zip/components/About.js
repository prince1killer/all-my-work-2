import React from 'react'

function About() {
  return (
    <div className='about'>About</div>
  )
}

export default About